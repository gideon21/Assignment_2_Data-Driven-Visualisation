<script>(function(){
function ac_add_to_head(el){
	var head = document.getElementsByTagName('head')[0];
	head.insertBefore(el,head.firstChild);
}
function ac_add_link(url){
	var el = document.createElement('link');
	el.rel='stylesheet';el.type='text/css';el.media='all';el.href=url;
	ac_add_to_head(el);
}
function ac_add_style(css){
	var ac_style = document.createElement('style');
	if (ac_style.styleSheet) ac_style.styleSheet.cssText = css;
	else ac_style.appendChild(document.createTextNode(css));
	ac_add_to_head(ac_style);
}
ac_add_link('https://cdn.anychart.com/releases/8.7.1/css/anychart-ui.min.css?hcode=a0c21fc77e1449cc86299c5faa067dc4');
ac_add_style(document.getElementById("ac_style_samples-wd-data-from-json-07").innerHTML);
ac_add_style(".anychart-embed-samples-wd-data-from-json-07{width:600px;height:450px;}");
})();</script>
<div id="container"></div>
<script>
anychart.onDocumentReady(function () {
                                // this column represents JS equivalents every JSON object
  var chart = anychart.fromJson(
    // set chart type
    {chart: {type: "line",              // var chart = anychart.line();

      // set series type
      series:[{seriesType: "spline",    // chart.spline(
// set series data
data: [                         //   [
      {x: "March 7th Deaths", value: 2},   //     ["March", 18000],,
      {x: "March 10th Deaths", value: 5},
      {x: "March 11th Deaths", value: 6},  
      {x: "March 12th Deaths", value: 8},  
      {x: "March 13th Deaths", value: 11},  
      {x: "March 14th Deaths", value: 21},
      {x: "March 15th Deaths", value: 35},
      {x: "March 16th Deaths", value: 53},  
      {x: "March 17th Deaths", value: 69},  
      {x: "March 18th Deaths", value: 104},  
      {x: "March 19th Deaths", value: 137},
      {x: "March 20th Deaths", value: 167},
      {x: "March 21st Deaths", value: 233},  
      {x: "March 22nd Deaths", value: 281},  
      {x: "March 23rd Deaths", value: 335},  
      {x: "March 24th Deaths", value: 422},
      {x: "March 25th Deaths", value: 463},
      {x: "March 26th Deaths", value: 578},  
      {x: "March 27th Deaths", value: 769},  
      {x: "March 28th Deaths", value: 1019},  
      {x: "March 29th Deaths", value: 1228},
      {x: "March 30th Deaths", value: 1408},
      {x: "March 31st Deaths", value: 1789},  
          {x: "April 1st Deaths", value: 2352},  
          {x: "April 2nd Deaths", value: 2931},  
          {x: "April 3rd Deaths", value: 3600},
          {x: "April 4th Deaths", value: 4313},
          {x: "April 5th Deaths", value: 4934},  
          {x: "April 6th Deaths", value: 5373},  
          {x: "April 7th Deaths", value: 6187},  
          {x: "April 8th Deaths", value: 7097},
          {x: "April 9th Deaths", value: 7978},
          {x: "April 10th Deaths", value: 8958},  
          {x: "April 11th Deaths", value: 9875},  
          {x: "April 12th Deaths", value: 10610},  
          {x: "April 13th Deaths", value: 11329},
          {x: "April 14th Deaths", value: 12107},
          {x: "April 15th Deaths", value: 12868},  
          {x: "April 16th Deaths", value: 13729},  
          {x: "April 17th Deaths", value: 14576},  
          {x: "April 18th Deaths", value: 15468},
          {x: "April 19th Deaths", value: 16060},
          {x: "April 20th Deaths", value: 16509},  
          {x: "April 21st Deaths", value: 17337},  
          {x: "April 22nd Deaths", value: 18100},//     ["April", 11000],
]}],                            //   ]);

      // set chart container
      container: "container"}}          //   chart.container("container"); 
  ).draw();                             
});
</script>